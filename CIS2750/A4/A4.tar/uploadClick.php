<html>
<head> <link rel="stylesheet" type="text/css" href="style.css"> </head>
<form action="uploadFile.php" method="post" enctype="multipart/form-data">
    <U><B>Select a file to upload:</B></u><BR><BR>
    	
    <input type="file" name="fileToUpload" id="fileToUpload" class="uploadClickButton">
    <input type="submit" value="Upload File" name="submit" class="submitClickButton">
</form>
</html>